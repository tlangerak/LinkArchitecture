structure = ReadWebPageStructure('Web_Page_Structure.csv');

%values of categories
categories{1,1} = 1; categories{1,2} = 'Electronics';
categories{2,1} = 2; categories{2,2} = 'Accesories';
categories{3,1} = 3; categories{3,2} = 'Household';
categories{4,1} = 4; categories{4,2} = 'Displays';
categories{5,1} = 5; categories{5,2} = 'Computing';
categories{6,1} = 6; categories{6,2} = 'Gifts';
categories{7,1} = 7; categories{7,2} = 'Jewelery';
categories{8,1} = 8; categories{8,2} = 'Refrigerator';
categories{9,1} = 9; categories{9,2} = 'Dishwasher';
categories{10,1} = 10; categories{10,2} = 'Television';
categories{11,1} = 11; categories{11,2} = 'Computer Monitors';
categories{12,1} = 12; categories{12,2} = 'Computer';
categories{13,1} = 13; categories{13,2} = 'Ipod';
categories{14,1} = 14; categories{14,2} = 'Diamond Rings';
categories{15,1} = 15; categories{15,2} = 'Gift Vouchers';
categories{16,1} = 16; categories{16,2} = 'Wrapping Papers';
categories{17,1} = 17; categories{17,2} = 'Emerald';
categories{18,1} = 18; categories{18,2} = 'Sapphire';